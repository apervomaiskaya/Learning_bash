#!/bin/bash
sudo find /home/oleg/Загрузки -name "*.jpeg" -exec mv {} /home/oleg/Документы \;
sudo find /home/oleg/Загрузки -name "*.mp3" -exec mv {} /home/oleg/Музыка \;
sudo find /home/oleg/Загрузки -name "*.docx" -exec mv {} /home/oleg/Документы \;






































