#!/bin/bash
date >> /home/oleg/Learn/current_time.txt

