#!/bin/bash
while true
do
    chmod +x *.sh
done